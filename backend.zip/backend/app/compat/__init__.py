# Compatibility patches
from . import numpy_compat  # noqa: F401
