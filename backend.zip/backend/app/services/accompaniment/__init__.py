"""Accompaniment helpers."""
